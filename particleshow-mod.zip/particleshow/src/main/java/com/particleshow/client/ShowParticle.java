package com.particleshow.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.particleshow.show.Kind;
import com.particleshow.show.Spec;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DefaultParticleType;

import java.util.concurrent.atomic.AtomicInteger;

/** Универсальная частица мода: свечение (аддитивное смешивание), плавное появление/затухание, рост, дрейф, мерцание. */
public class ShowParticle extends SpriteBillboardParticle {
    /** Сколько частиц шоу сейчас живо (в очереди ParticleManager максимум 16384 на тип отрисовки). */
    public static final AtomicInteger LIVE = new AtomicInteger();
    public static final int LIMIT = 15500;

    static final ParticleTextureSheet ADDITIVE = new ParticleTextureSheet() {
        @Override
        public void begin(BufferBuilder builder, TextureManager textureManager) {
            RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getParticleProgram);
            RenderSystem.setShaderTexture(0, SpriteAtlasTexture.PARTICLE_ATLAS_TEXTURE);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
            builder.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR_LIGHT);
        }

        @Override
        public void draw(Tessellator tessellator) {
            tessellator.draw();
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(true);
        }

        @Override
        public String toString() { return "PARTICLESHOW_ADDITIVE"; }
    };

    private final float baseAlpha, drag, gravity, rise, grow;
    private final int fadeIn, fadeOut;
    private final boolean twinkle, additive;
    private final float phase;
    private boolean counted = true;

    public ShowParticle(ClientWorld world, SpriteProvider sprites, Spec s) {
        super(world, s.x, s.y, s.z, 0, 0, 0);
        this.velocityX = s.vx;
        this.velocityY = s.vy;
        this.velocityZ = s.vz;
        this.maxAge = Math.max(1, s.life);
        this.scale = s.size;
        this.red = ((s.rgb >> 16) & 255) / 255f;
        this.green = ((s.rgb >> 8) & 255) / 255f;
        this.blue = (s.rgb & 255) / 255f;
        this.baseAlpha = s.alpha;
        this.drag = s.drag;
        this.gravity = s.gravity;
        this.rise = s.rise;
        this.grow = s.grow;
        this.fadeIn = Math.max(0, s.fadeIn);
        this.fadeOut = s.fadeOut >= 0 ? s.fadeOut : Math.min(this.maxAge / 3, 20);
        this.twinkle = s.twinkle;
        this.additive = s.additive;
        this.phase = this.random.nextFloat() * 6.28f;
        this.collidesWithWorld = false;
        this.gravityStrength = 0f;
        this.alpha = this.fadeIn > 0 ? 0f : this.baseAlpha;
        this.setSprite(sprites.getSprite(this.random));
        LIVE.incrementAndGet();
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
        if (this.age++ >= this.maxAge) {
            die();
            return;
        }
        this.velocityY -= gravity;
        int left = this.maxAge - this.age;
        if (this.fadeOut > 0 && left < this.fadeOut) this.velocityY += rise;
        this.x += this.velocityX;
        this.y += this.velocityY;
        this.z += this.velocityZ;
        this.velocityX *= drag;
        this.velocityY *= drag;
        this.velocityZ *= drag;
        if (grow != 0f) this.scale = Math.max(0.001f, this.scale + grow);

        float a = baseAlpha;
        if (fadeIn > 0 && this.age < fadeIn) a *= (this.age + 1f) / fadeIn;
        if (fadeOut > 0 && left < fadeOut) a *= left / (float) fadeOut;
        if (twinkle) a *= 0.65f + 0.35f * (float) Math.sin(this.age * 0.9f + phase);
        this.alpha = Math.max(0f, Math.min(1f, a));
    }

    private void die() {
        if (counted) {
            counted = false;
            LIVE.decrementAndGet();
        }
        this.markDead();
    }

    @Override
    public ParticleTextureSheet getType() {
        return additive ? ADDITIVE : ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getBrightness(float tint) { return 15728880; }

    /** Фабрика для частиц, вызванных обычной командой /particle particleshow:glow ... */
    public static class Factory implements ParticleFactory<DefaultParticleType> {
        private final SpriteProvider sprites;
        private final Kind kind;

        public Factory(SpriteProvider sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(DefaultParticleType type, ClientWorld world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            Spec s = new Spec(kind).pos(x, y, z).vel(vx, vy, vz).life(40).size(0.3).color(0xFFFFFF).fade(2, 12);
            return new ShowParticle(world, sprites, s);
        }
    }
}
