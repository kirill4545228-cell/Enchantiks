package com.particleshow.client;

import com.particleshow.ModParticles;
import com.particleshow.ParticleShowMod;
import com.particleshow.show.Kind;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.util.math.Vec3d;

import java.util.EnumMap;
import java.util.Map;

public class ParticleShowClient implements ClientModInitializer {
    public static final Map<Kind, SpriteProvider> PROVIDERS = new EnumMap<>(Kind.class);

    @Override
    public void onInitializeClient() {
        for (Kind k : Kind.values()) {
            ParticleFactoryRegistry.getInstance().register(ModParticles.of(k), sprites -> {
                PROVIDERS.put(k, sprites);
                return new ShowParticle.Factory(sprites, k);
            });
        }

        ClientPlayNetworking.registerGlobalReceiver(ParticleShowMod.PLAY, (client, handler, buf, sender) -> {
            String id = buf.readString();
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float scale = buf.readFloat();
            long seed = buf.readLong();
            client.execute(() -> ShowManager.start(id, new Vec3d(x, y, z), scale, seed));
        });

        ClientTickEvents.END_CLIENT_TICK.register(ShowManager::tick);
    }
}
