package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Вращающаяся спиральная галактика: 4 логарифмических рукава, яркое ядро, вспышки сверхновых, коллапс в финале. */
public final class GalaxyShow implements Show {
    private static final double PY = 50, R0 = 70, TILT = 0.5;
    private static final double CT = Math.cos(TILT), ST = Math.sin(TILT);

    @Override public String id() { return "galaxy"; }
    @Override public String title() { return "Спиральная галактика с ядром, рукавами и сверхновыми"; }
    @Override public int duration() { return 780; }
    @Override public double distance() { return 105; }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:block.beacon.activate", 1f, 0.5f);
        if (t == 760) {
            Vec3d p = c.at(0, PY, 0);
            c.emit(new Spec(Kind.GLOW).pos(p).life(14).size(20).color(0xFFFFFF).alpha(0.9).fade(1, 12));
            for (int i = 0; i < 320; i++) {
                Vec3d d = Fx.randDir(r).multiply(2.0);
                c.emit(new Spec(Kind.GLOW).pos(p).vel(d).drag(0.94).life(45).size(0.7)
                        .color(i % 2 == 0 ? 0xCFE0FF : 0xFFFFFF).fade(1, 25));
            }
            c.sound("minecraft:entity.generic.explode", 0.8f, 0.5f);
        }
        double R = R0 * Fx.smooth(t / 130.0) * (1 - Fx.smooth((t - 680) / 80.0));
        if (R < 1) return;
        double spin = t * 0.012;
        for (int i = 0; i < 430; i++) {
            int arm = r.nextInt(4);
            double rho = R * Math.pow(r.nextDouble(), 0.7);
            double th = arm * Fx.TAU / 4 + 4.2 * Math.pow(rho / R0, 0.8) + r.nextGaussian() * (0.1 + 0.7 * Math.exp(-rho / 10)) + spin;
            double x = rho * Math.cos(th), z = rho * Math.sin(th);
            double y = r.nextGaussian() * (0.5 + 2.2 * Math.exp(-rho / 9));
            double yy = y * CT - z * ST, zz = y * ST + z * CT;
            double sp = rho * 0.012, tx = -Math.sin(th) * sp, tz = Math.cos(th) * sp;
            double q = rho / R0, p = r.nextDouble();
            int col;
            if (rho < 10) col = Fx.mix(0xFFF0C8, 0xFFD890, rho / 10);
            else if (p < 0.07) col = 0xFF78C8;
            else col = Fx.mix(0xCFE0FF, 0x6C9CFF, q);
            c.emit(new Spec(Kind.GLOW).pos(c.at(x, PY + yy, zz)).vel(tx, -tz * ST, tz * CT).life(12)
                    .size(rho < 10 ? 0.75 : 0.5).color(col).alpha(0.7).fade(2, 6));
        }
        double f = R / R0;
        for (int i = 0; i < 70; i++) {
            c.emit(new Spec(Kind.GLOW).pos(c.at(r.nextGaussian() * 5 * f, PY + r.nextGaussian() * 3 * f, r.nextGaussian() * 5 * f))
                    .life(8).size(0.9).color(i % 2 == 0 ? 0xFFD890 : 0xFFE8B8).alpha(0.45).fade(2, 5));
        }
        Vec3d core = c.at(0, PY, 0);
        c.emit(new Spec(Kind.GLOW).pos(core).life(3).size(4.5 * f).color(0xFFFFFF).fade(1, 2));
        c.emit(new Spec(Kind.STAR).pos(core).life(3).size(8 * f).color(0xFFE0A0).alpha(0.5).fade(1, 2));
        if (r.nextInt(14) == 0) {
            double rho = R * (0.2 + 0.8 * r.nextDouble()), th = r.nextDouble() * Fx.TAU;
            double x = rho * Math.cos(th), z = rho * Math.sin(th);
            Vec3d sp = c.at(x, PY - z * ST, z * CT);
            c.emit(new Spec(Kind.GLOW).pos(sp).life(10).size(3).color(0xFFFFFF).fade(1, 8));
            c.emit(new Spec(Kind.RING).pos(sp).life(16).size(0.3).grow(0.35).color(0xBFD8FF).alpha(0.8).fade(1, 12));
        }
    }
}
