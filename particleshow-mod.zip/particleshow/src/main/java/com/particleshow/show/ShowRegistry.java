package com.particleshow.show;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ShowRegistry {
    private static final Map<String, Show> SHOWS = new LinkedHashMap<>();

    static {
        add(new MindFlayerShow());
        add(new GalaxyShow());
        add(new DnaShow());
        add(new BlackHoleShow());
        add(new TornadoShow());
        add(new PhoenixShow());
        add(new FireworksShow());
        add(new AuroraShow());
        add(new RiftShow());
        add(new MeteorShow());
        add(new HypercubeShow());
    }

    private ShowRegistry() {}

    private static void add(Show s) { SHOWS.put(s.id(), s); }
    public static Show get(String id) { return SHOWS.get(id); }
    public static List<String> ids() { return new ArrayList<>(SHOWS.keySet()); }
    public static Iterable<Show> all() { return SHOWS.values(); }
}
