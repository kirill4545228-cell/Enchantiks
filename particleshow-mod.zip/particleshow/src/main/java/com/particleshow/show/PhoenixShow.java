package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Огненный феникс: размах крыльев ~50 блоков, машет крыльями, летит по кругу, оставляет шлейф углей и взрывается пламенем. */
public final class PhoenixShow implements Show {
    @Override public String id() { return "phoenix"; }
    @Override public String title() { return "Огненный феникс с машущими крыльями"; }
    @Override public int duration() { return 760; }
    @Override public double distance() { return 75; }

    private Vec3d path(int t) {
        double a = -0.6 + t * 0.017;
        double h = 50 + 12 * Math.sin(a * 1.5) + (t > 600 ? (t - 600) * 0.45 : 0);
        return new Vec3d(48 * Math.cos(a), h, 48 * Math.sin(a));
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t > 700) return;
        if (t == 690) {
            Vec3d P = path(t);
            Vec3d w = c.at(P.x, P.y, P.z);
            c.emit(new Spec(Kind.GLOW).pos(w).life(16).size(18).color(0xFFE0A0).alpha(0.9).fade(1, 14));
            for (int i = 0; i < 520; i++) {
                Vec3d d = Fx.randDir(r).multiply(1.4 + r.nextDouble() * 1.0);
                c.emit(new Spec(Kind.GLOW).pos(w).vel(d).drag(0.94).gravity(0.004).life(60).size(0.7)
                        .color(Fx.mix(0xFFD060, 0xFF3010, r.nextDouble())).fade(1, 35));
            }
            c.sound("minecraft:entity.generic.explode", 0.7f, 0.8f);
            c.sound("minecraft:entity.blaze.shoot", 1f, 0.6f);
            return;
        }
        if (t > 690) return;
        if (t == 0) c.sound("minecraft:entity.blaze.shoot", 1f, 0.7f);
        if (t % 29 == 0) c.sound("minecraft:entity.ender_dragon.flap", 0.9f, 1.3f);

        Vec3d P = path(t), Pn = path(t + 1);
        Vec3d vel = Pn.subtract(P);
        Vec3d f = vel.normalize();
        Vec3d up = new Vec3d(0, 1, 0);
        Vec3d rt = f.crossProduct(up).normalize();
        Vec3d u = rt.crossProduct(f).normalize();
        double phi = 0.7 * Math.sin(t * 0.22) + 0.12;

        // тело, голова, клюв
        for (double s = -5; s <= 4; s += 0.5) {
            Vec3d q = P.add(f.multiply(s));
            c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, q.y, q.z)).vel(vel).life(3).size(0.9 - Math.abs(s) * 0.03)
                    .color(Fx.mix(0xFF9A20, 0xFFF0C0, 1 - Math.abs(s) / 6)).fade(1, 2));
        }
        Vec3d head = P.add(f.multiply(5.8)).add(u.multiply(0.8));
        c.emit(new Spec(Kind.GLOW).pos(c.at(head.x, head.y, head.z)).vel(vel).life(3).size(1.5).color(0xFFFFFF).fade(1, 2));
        for (int k = 0; k < 3; k++) {
            Vec3d b = head.add(f.multiply(1.0 + k * 0.7)).subtract(u.multiply(0.2 * k));
            c.emit(new Spec(Kind.GLOW).pos(c.at(b.x, b.y, b.z)).vel(vel).life(3).size(0.4).color(0xFF8A20).fade(1, 2));
        }

        // крылья
        for (int sg = -1; sg <= 1; sg += 2) {
            for (int k = 0; k < 14; k++) {
                double beta = -0.25 + k * 0.085;
                double len = 9 + 17 * Math.sin(Math.PI * (k + 1) / 15.0);
                Vec3d d0 = rt.multiply(sg * Math.cos(beta)).subtract(f.multiply(Math.sin(beta)));
                Vec3d d = Fx.rot(d0, f, -sg * phi);
                for (double s = 0.8; s < len; s += 0.75) {
                    double x = s / len;
                    Vec3d pos = P.add(f.multiply(1.2)).add(d.multiply(s)).subtract(u.multiply(0.006 * s * s));
                    int col = x < 0.35 ? Fx.mix(0xFFF6D0, 0xFFC040, x / 0.35) : Fx.mix(0xFFC040, 0xFF3A12, (x - 0.35) / 0.65);
                    c.emit(new Spec(Kind.GLOW).pos(c.at(pos.x, pos.y, pos.z)).vel(vel).life(3).size(0.55)
                            .color(col).alpha(0.8 - 0.3 * x).fade(1, 2));
                }
                if (k % 3 == 0) {
                    Vec3d tip = P.add(f.multiply(1.2)).add(d.multiply(len));
                    c.emit(new Spec(Kind.STAR).pos(c.at(tip.x, tip.y, tip.z)).vel(vel).life(4).size(1.3).color(0xFFD080).fade(1, 3));
                }
            }
        }

        // хвост
        for (int m = -2; m <= 2; m++) {
            for (double s = 1; s < 24; s += 0.8) {
                double x = s / 24;
                Vec3d pos = P.subtract(f.multiply(s + 3)).add(rt.multiply(m * 0.9 * x * 1.5))
                        .add(u.multiply(Math.sin(s * 0.35 - t * 0.3) * 0.9 * x * 2));
                c.emit(new Spec(Kind.GLOW).pos(c.at(pos.x, pos.y, pos.z)).vel(vel).life(4).size(0.5)
                        .color(Fx.mix(0xFFC040, 0xFF2A10, x)).alpha(0.8 - 0.4 * x).fade(1, 3));
            }
        }

        // шлейф углей
        for (int i = 0; i < 28; i++) {
            Vec3d q = P.subtract(f.multiply(r.nextDouble() * 4));
            c.emit(new Spec(Kind.EMBER).pos(c.at(q.x + r.nextGaussian() * 0.8, q.y + r.nextGaussian() * 0.8, q.z + r.nextGaussian() * 0.8))
                    .vel(r.nextGaussian() * 0.04, r.nextGaussian() * 0.04, r.nextGaussian() * 0.04).gravity(-0.004)
                    .life(45).size(0.35 + 0.25 * r.nextDouble()).color(Fx.mix(0xFFB030, 0xFF3A10, r.nextDouble())).alpha(0.8).fade(2, 25));
        }
    }
}
