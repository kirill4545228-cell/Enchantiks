package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Чёрная дыра: аккреционный диск (спиральные потоки по падающим траекториям), фотонное кольцо, линзирование, релятивистские джеты. */
public final class BlackHoleShow implements Show {
    private static final double PY = 52, TILT = 0.38;
    private static final int STREAMS = 190;
    private final double[] th0 = new double[STREAMS];

    public BlackHoleShow() {
        for (int j = 0; j < STREAMS; j++) th0[j] = j * 2.399963;
    }

    @Override public String id() { return "blackhole"; }
    @Override public String title() { return "Чёрная дыра с аккреционным диском и джетами"; }
    @Override public int duration() { return 900; }
    @Override public double distance() { return 110; }

    private Vec3d xf(double x, double y, double z, int t) {
        double yy = y * Math.cos(TILT) - z * Math.sin(TILT), zz = y * Math.sin(TILT) + z * Math.cos(TILT);
        double a = t * 0.003;
        return new Vec3d(x * Math.cos(a) + zz * Math.sin(a), yy, -x * Math.sin(a) + zz * Math.cos(a));
    }

    private static int diskColor(double rho) {
        return rho < 14 ? Fx.mix(0xE8F2FF, 0xFFC07A, (rho - 6) / 8) : Fx.mix(0xFFC07A, 0xC03010, (rho - 14) / 36);
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:entity.wither.spawn", 0.6f, 0.5f);
        if (t == 800) {
            Vec3d p = c.at(0, PY, 0);
            c.emit(new Spec(Kind.GLOW).pos(p).life(14).size(18).color(0xFFFFFF).alpha(0.9).fade(1, 12));
            for (int i = 0; i < 360; i++) {
                double a = i * Fx.TAU / 360;
                Vec3d v = xf(Math.cos(a) * 2.2, 0, Math.sin(a) * 2.2, t);
                c.emit(new Spec(Kind.GLOW).pos(p).vel(v).drag(0.95).life(50).size(0.7).color(0xFFB070).fade(1, 30));
            }
            c.sound("minecraft:entity.generic.explode", 0.8f, 0.5f);
        }
        double env = Fx.smooth(t / 140.0) * (1 - Fx.smooth((t - 790) / 90.0));
        if (env < 0.02) return;
        double dt = 0.0055;
        for (int j = 0; j < STREAMS; j++) {
            double f = Fx.frac(j / (double) STREAMS + t * dt);
            double f2 = f + dt;
            double rho1 = (6 + 44 * Math.pow(1 - f, 1.5)) * env, rho2 = (6 + 44 * Math.pow(Math.max(0, 1 - f2), 1.5)) * env;
            double th1 = th0[j] + 6.5 * Math.pow(f, 0.55) + t * 0.01, th2 = th0[j] + 6.5 * Math.pow(f2, 0.55) + (t + 1) * 0.01;
            double y = r.nextGaussian() * 0.3 * (rho1 / 20);
            Vec3d p1 = xf(rho1 * Math.cos(th1), y, rho1 * Math.sin(th1), t);
            Vec3d p2 = xf(rho2 * Math.cos(th2), y, rho2 * Math.sin(th2), t + 1);
            double a = Math.min(1, f / 0.06) * 0.8;
            c.emit(new Spec(Kind.GLOW).pos(c.at(p1.x, PY + p1.y, p1.z)).vel(p2.subtract(p1)).life(20).size(0.5)
                    .color(diskColor(rho1 / Math.max(env, 0.2))).alpha(a).fade(2, 14));
        }
        for (int i = 0; i < 120; i++) {
            double a = r.nextDouble() * Fx.TAU;
            Vec3d p = xf(Math.cos(a) * 9.5 * env, 0, Math.sin(a) * 9.5 * env, t);
            c.emit(new Spec(Kind.GLOW).pos(c.at(p.x, PY + p.y, p.z)).life(3).size(0.4).color(0xDDEBFF).alpha(0.9).fade(1, 2));
        }
        Vec3d v = c.toViewer();
        Vec3d rt = new Vec3d(-v.z, 0, v.x);
        for (int i = 0; i < 90; i++) {
            double a = r.nextDouble() * Fx.TAU, rad = 12 * env + r.nextGaussian() * 0.25;
            c.emit(new Spec(Kind.GLOW).pos(c.at(rt.x * Math.cos(a) * rad, PY + Math.sin(a) * rad, rt.z * Math.cos(a) * rad))
                    .life(3).size(0.45).color(0xFFB878).alpha(0.6).fade(1, 2));
        }
        if (t > 100) {
            for (int sg = -1; sg <= 1; sg += 2) {
                for (int i = 0; i < 12; i++) {
                    double a = r.nextDouble() * Fx.TAU, rad = r.nextDouble() * 1.2;
                    c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(a) * rad, PY + sg * 6, Math.sin(a) * rad))
                            .vel(-Math.sin(a) * 0.1, sg * (1.5 + 0.8 * r.nextDouble()), Math.cos(a) * 0.1)
                            .life(38).size(0.5).color(Fx.mix(0xCFE6FF, 0x5C80FF, r.nextDouble())).alpha(0.75).fade(2, 14));
                }
            }
        }
        c.emit(new Spec(Kind.GLOW).pos(c.at(0, PY, 0)).life(2).size(2.2 * env).color(0xFFE6C8).alpha(0.25).fade(0, 1));
    }
}
