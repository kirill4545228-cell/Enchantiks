package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/** Тессеракт: вращающийся 4D-гиперкуб, настоящая перспективная проекция из 4 измерений в 3. Внутри - второй, вращающийся навстречу. */
public final class HypercubeShow implements Show {
    private static final double PY = 44;

    @Override public String id() { return "hypercube"; }
    @Override public String title() { return "Тессеракт: вращающийся 4D-гиперкуб"; }
    @Override public int duration() { return 840; }
    @Override public double distance() { return 70; }

    private static void rot(double[] p, int i, int j, double a) {
        double ci = p[i] * Math.cos(a) - p[j] * Math.sin(a), cj = p[i] * Math.sin(a) + p[j] * Math.cos(a);
        p[i] = ci; p[j] = cj;
    }

    private static double[][] verts(int t, double dir) {
        double[][] out = new double[16][];
        for (int i = 0; i < 16; i++) {
            double[] p = {(i & 1) * 2 - 1, ((i >> 1) & 1) * 2 - 1, ((i >> 2) & 1) * 2 - 1, ((i >> 3) & 1) * 2 - 1};
            rot(p, 0, 3, dir * t * 0.011);
            rot(p, 1, 3, dir * t * 0.0077);
            rot(p, 2, 3, dir * t * 0.0053);
            rot(p, 0, 2, dir * t * 0.004);
            out[i] = p;
        }
        return out;
    }

    private void draw(ShowContext c, int t, double S, double dir, double alpha) {
        double[][] v = verts(t, dir);
        for (int i = 0; i < 16; i++) {
            for (int b = 0; b < 4; b++) {
                int j = i ^ (1 << b);
                if (j < i) continue;
                for (int m = 0; m <= 26; m++) {
                    double f = m / 26.0;
                    double x = Fx.lerp(v[i][0], v[j][0], f), y = Fx.lerp(v[i][1], v[j][1], f);
                    double z = Fx.lerp(v[i][2], v[j][2], f), w = Fx.lerp(v[i][3], v[j][3], f);
                    double k = 2.6 / (2.6 - w) * S;
                    c.emit(new Spec(Kind.GLOW).pos(c.at(x * k, PY + y * k, z * k)).life(2).size(0.38)
                            .color(Fx.mix(0x30E8FF, 0xFF40E0, (w + 1) / 2)).alpha(alpha).fade(0, 1));
                }
            }
            double k = 2.6 / (2.6 - v[i][3]) * S;
            c.emit(new Spec(Kind.GLOW).pos(c.at(v[i][0] * k, PY + v[i][1] * k, v[i][2] * k)).life(2).size(1.3)
                    .color(Fx.mix(0x9AF4FF, 0xFFA0F0, (v[i][3] + 1) / 2)).fade(0, 1));
        }
    }

    @Override
    public void tick(ShowContext c, int t) {
        Random r = c.rng();
        if (t == 0) c.sound("minecraft:block.beacon.power_select", 1f, 0.8f);
        if (t == 820) {
            Vec3d p = c.at(0, PY, 0);
            c.emit(new Spec(Kind.GLOW).pos(p).life(14).size(14).color(0xFFFFFF).alpha(0.9).fade(1, 12));
            for (int i = 0; i < 300; i++)
                c.emit(new Spec(Kind.GLOW).pos(p).vel(Fx.randDir(r).multiply(2)).drag(0.94).life(40).size(0.6)
                        .color(Fx.hsv(i / 300.0, 0.6, 1)).fade(1, 25));
            c.sound("minecraft:entity.generic.explode", 0.7f, 1.2f);
            return;
        }
        if (t > 820) return;
        double grow = Fx.smooth(t / 90.0) * (1 - Fx.smooth((t - 760) / 60.0));
        if (grow < 0.02) return;
        draw(c, t, 13 * grow, 1, 0.75);
        draw(c, t, 6.5 * grow, -1.3, 0.6);
        for (int j = 0; j < 3; j++) {
            double a = t * 0.07 + j * 2.1;
            Vec3d nrm = new Vec3d(Math.sin(t * 0.01 + j), Math.cos(t * 0.013 + j * 2), Math.sin(t * 0.008 + j * 3)).normalize();
            Vec3d b1 = Fx.perp(nrm), b2 = nrm.crossProduct(b1);
            Vec3d q = b1.multiply(Math.cos(a) * 24 * grow).add(b2.multiply(Math.sin(a) * 24 * grow));
            c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, PY + q.y, q.z)).life(24).size(0.6).color(Fx.hsv(t * 0.01 + j / 3.0, 0.7, 1)).fade(1, 20));
            c.emit(new Spec(Kind.STAR).pos(c.at(q.x, PY + q.y, q.z)).life(2).size(1.4).color(0xFFFFFF).fade(0, 1));
        }
    }
}
