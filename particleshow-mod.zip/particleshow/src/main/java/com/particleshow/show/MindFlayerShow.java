package com.particleshow.show;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/**
 * Истязатель разума.
 * 1) светящаяся точка; 2) вокруг неё "плывут" 48 полосок из частиц по большим кругам и сплетаются в шар;
 * 3) из шара вырастают 8 изогнутых ног-трубок (параметрическая кривая), касаясь земли ударной волной;
 * 4) тело рисуется сверху вниз кольцами (веретено с рёбрами); 5) красная буря, молнии, финальный взрыв и рассыпание.
 */
public final class MindFlayerShow implements Show {
    private static final double PY = 58;
    private static final int HEADS = 48, LEGS = 8, END = 830;
    private static final double RS = 15;
    private static final double[] LEG_L = {62, 70, 58, 74, 64, 72, 60, 68};
    private static final double[] LEG_Y0 = {50, 58, 48, 56, 52, 60, 47, 55};
    private static final double[] LEG_A = {12, 20, 16, 24, 14, 22, 18, 10};
    private static final int[] HEAD_COL = {0xFFE2A8, 0xFF8A3A, 0xFF3A22};

    private final Vec3d[] axis = new Vec3d[HEADS];
    private final Vec3d[] start = new Vec3d[HEADS];
    private final double[] omega = new double[HEADS];
    private final double[] legPhi = new double[LEGS];

    public MindFlayerShow() {
        Random r = new Random(7);
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < HEADS; i++) {
            double y = 1 - 2.0 * (i + 0.5) / HEADS, rad = Math.sqrt(1 - y * y), th = i * golden;
            axis[i] = new Vec3d(Math.cos(th) * rad, y, Math.sin(th) * rad);
            start[i] = Fx.perp(axis[i]);
            omega[i] = (0.055 + 0.05 * r.nextDouble()) * (i % 2 == 0 ? 1 : -1);
        }
        for (int i = 0; i < LEGS; i++) legPhi[i] = i * Math.PI / 4 + 0.35;
    }

    @Override public String id() { return "mindflayer"; }
    @Override public String title() { return "Истязатель разума: точка -> шар из полосок -> гигантский монстр"; }
    @Override public int duration() { return 880; }
    @Override public double distance() { return 110; }

    @Override
    public void tick(ShowContext c, int t) {
        if (t == 0) c.sound("minecraft:entity.warden.heartbeat", 1f, 0.6f);
        if (t == 40) c.sound("minecraft:block.beacon.activate", 1f, 0.5f);
        if (t == 300) c.sound("minecraft:entity.ender_dragon.growl", 1f, 0.5f);
        if (t == 770) c.sound("minecraft:entity.warden.sonic_boom", 1f, 0.6f);
        if (t > 0 && t % 36 == 0 && t < END) c.sound("minecraft:entity.warden.heartbeat", 0.8f, 0.6f);
        core(c, t);
        sphere(c, t);
        legs(c, t);
        body(c, t);
        storm(c, t);
        finale(c, t);
    }

    // ---------- ядро (точка) ----------
    private void core(ShowContext c, int t) {
        if (t > END) return;
        double g = Fx.smooth(t / 40.0);
        double sz = (0.4 + 1.7 * g) * (1 + 0.25 * Math.sin(t * 0.22));
        Vec3d p = c.at(0, PY, 0);
        c.emit(new Spec(Kind.GLOW).pos(p).life(4).size(sz).color(0xFFF0DC).fade(1, 3));
        c.emit(new Spec(Kind.STAR).pos(p).life(4).size(sz * 1.9).color(0xFF5030).alpha(0.7).fade(1, 3));
        if (t >= 20 && t < 150 && t % 18 == 2)
            c.emit(new Spec(Kind.RING).pos(p).life(24).size(0.5).grow(0.9).color(0xFF6A3A).alpha(0.8).fade(2, 18));
        if (t >= 150 && t % 30 == 0 && t < END - 40)
            c.emit(new Spec(Kind.RING).pos(p).life(30).size(0.8).grow(1.5).color(0xFF3A22).alpha(0.7).fade(2, 22));
    }

    // ---------- шар из полосок ----------
    private double rs(int t) {
        if (t < 40 || t > 400) return 0;
        double up = Fx.smooth((t - 40) / 100.0);
        double down = 1 - 0.55 * Fx.smooth((t - 330) / 70.0);
        return RS * up * down;
    }

    private void sphere(ShowContext c, int t) {
        double R = rs(t);
        if (R <= 0) return;
        for (int i = 0; i < HEADS; i++) {
            for (int sub = 0; sub < 2; sub++) {
                Vec3d v = Fx.rot(start[i], axis[i], omega[i] * (t + sub * 0.5)).multiply(R);
                Vec3d w = c.at(v.x, PY + v.y, v.z);
                c.emit(new Spec(Kind.GLOW).pos(w).life(22).size(0.45).color(HEAD_COL[i % 3]).alpha(0.85).fade(1, 18));
                if (sub == 0) c.emit(new Spec(Kind.STAR).pos(w).life(2).size(0.95).color(0xFFFFFF).fade(0, 1));
            }
        }
    }

    // ---------- ноги ----------
    private Vec3d leg(int i, double s) {
        double d = 6 + (LEG_L[i] - 6) * Math.pow(s, 0.8);
        double y = LEG_Y0[i] + LEG_A[i] * Math.sin(Math.PI * Math.pow(s, 0.7)) - LEG_Y0[i] * s * s;
        return new Vec3d(Math.cos(legPhi[i]) * d, y, Math.sin(legPhi[i]) * d);
    }

    private static double legW(double s) { return 0.3 + 2.4 * Math.pow(1 - s, 1.1); }

    private void legs(ShowContext c, int t) {
        for (int i = 0; i < LEGS; i++) {
            int t0 = 160 + i * 10;
            double p0 = Fx.ramp(t - 1, t0, t0 + 150), p1 = Fx.ramp(t, t0, t0 + 150);
            if (p1 > p0) {
                for (double s = p0; s < p1; s += 1.0 / 270) tube(c, i, s, t);
                Vec3d h = leg(i, p1);
                c.emit(new Spec(Kind.GLOW).pos(c.at(h.x, h.y, h.z)).life(3).size(2.0).color(0xFFFFFF).fade(0, 2));
                c.emit(new Spec(Kind.STAR).pos(c.at(h.x, h.y, h.z)).life(3).size(3.2).color(0xFF6A3A).alpha(0.8).fade(0, 2));
            }
            if (p1 >= 1 && p0 < 1) impact(c, i);
            if (t > t0 + 150 && t < END - 40) {
                double s = ((t - t0) % 60) / 60.0;
                Vec3d q = leg(i, s);
                c.emit(new Spec(Kind.GLOW).pos(c.at(q.x, q.y, q.z)).life(3).size(1.0 + (1 - s) * 1.2).color(0xFFE0B0).alpha(0.9).fade(0, 2));
            }
        }
    }

    private void tube(ShowContext c, int i, double s, int t) {
        Random r = c.rng();
        Vec3d a = leg(i, s), b = leg(i, Math.min(1, s + 0.01));
        Vec3d T = b.subtract(a);
        if (T.lengthSquared() < 1e-9) return;
        T = T.normalize();
        Vec3d n1 = Fx.perp(T), n2 = T.crossProduct(n1);
        double w = legW(s);
        int k = w > 1.6 ? 4 : (w > 0.9 ? 3 : 2);
        double base = r.nextDouble() * Fx.TAU;
        int col = Fx.mix(0xFF1E0E, 0xFFA060, s);
        for (int j = 0; j < k; j++) {
            double ang = base + j * Fx.TAU / k;
            Vec3d o = n1.multiply(Math.cos(ang) * w).add(n2.multiply(Math.sin(ang) * w));
            c.emit(new Spec(Kind.GLOW).pos(c.at(a.x + o.x, a.y + o.y, a.z + o.z)).life(END - t).size(0.5)
                    .color(col).alpha(0.8).fade(4, 45).rise(0.004));
        }
    }

    private void impact(ShowContext c, int i) {
        Random r = c.rng();
        Vec3d e = leg(i, 1.0);
        Vec3d g = c.at(e.x, 0.4, e.z);
        Fx.shock(c, g, 1.1, 48, 0xFF5A2A, 26, 0.5);
        c.emit(new Spec(Kind.RING).pos(g).life(24).size(0.5).grow(0.8).color(0xFF4A2A).alpha(0.8).fade(1, 18));
        for (int k = 0; k < 30; k++)
            c.emit(new Spec(Kind.EMBER).pos(g).vel(r.nextGaussian() * 0.2, 0.3 + r.nextDouble() * 0.5, r.nextGaussian() * 0.2)
                    .gravity(0.03).life(30).size(0.35).color(0xFF9A40).fade(1, 14));
        c.sound("minecraft:entity.generic.explode", 0.5f, 0.6f);
    }

    // ---------- тело ----------
    private void body(ShowContext c, int t) {
        if (t < 300 || t >= END) return;
        Random r = c.rng();
        int N = 56;
        double q0 = Fx.ramp(t - 1, 300, 440), q1 = Fx.ramp(t, 300, 440);
        int k0 = (int) Math.floor(q0 * N), k1 = Math.min(N, (int) Math.floor(q1 * N));
        for (int k = k0; k < k1; k++) {
            double u = (k + 0.5) / N;
            double y = PY + 24 * (1 - 2 * u);
            double rb = 8.5 * Math.pow(Math.sin(Math.PI * u), 0.8) * (1 + 0.09 * Math.sin(u * 46));
            int n = Math.max(8, (int) (Fx.TAU * rb / 0.8));
            double off = r.nextDouble() * Fx.TAU;
            int col = Fx.mix(0xFF3A1E, 0xFFD090, 1 - Math.abs(2 * u - 1));
            for (int j = 0; j < n; j++) {
                double ang = off + j * Fx.TAU / n;
                c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rb, y, Math.sin(ang) * rb)).life(END - t).size(0.5)
                        .color(col).alpha(0.8).fade(4, 45).rise(0.004));
            }
            c.emit(new Spec(Kind.GLOW).pos(c.at(0, y, 0)).life(4).size(rb * 0.5 + 0.5).color(0xFFB080).alpha(0.5).fade(1, 3));
        }
    }

    // ---------- красная буря ----------
    private void storm(ShowContext c, int t) {
        if (t < 200 || t > END) return;
        Random r = c.rng();
        double env = Fx.ramp(t, 200, 300) * (1 - Fx.ramp(t, END - 60, END));
        int n = (int) (14 * env);
        for (int i = 0; i < n; i++) {
            double ang = r.nextDouble() * Fx.TAU, rad = 18 + r.nextDouble() * 80, y = 96 + r.nextDouble() * 16;
            c.emit(new Spec(Kind.GLOW).pos(c.at(Math.cos(ang) * rad, y, Math.sin(ang) * rad))
                    .vel(-Math.sin(ang) * 0.18, 0, Math.cos(ang) * 0.18).life(50).size(5 + 3 * r.nextDouble())
                    .color(Fx.mix(0x7A0C10, 0xC02A18, r.nextDouble())).alpha(0.16).fade(15, 25));
        }
        if (t > 260 && t < END - 30 && r.nextInt(22) == 0) {
            double ang = r.nextDouble() * Fx.TAU, rad = 20 + r.nextDouble() * 50;
            Vec3d a = c.at(Math.cos(ang) * rad * 0.6, 100, Math.sin(ang) * rad * 0.6);
            Vec3d b = c.at(Math.cos(ang) * rad, 0.5, Math.sin(ang) * rad);
            Fx.bolt(c, a, b, 0xFF6A50, 0.55, 7, 6);
            c.sound("minecraft:entity.lightning_bolt.thunder", 0.6f, 0.7f);
        }
    }

    // ---------- финал ----------
    private void finale(ShowContext c, int t) {
        if (t != 770) return;
        Random r = c.rng();
        Vec3d p = c.at(0, PY, 0);
        c.emit(new Spec(Kind.GLOW).pos(p).life(14).size(16).color(0xFFFFFF).alpha(0.9).fade(1, 12));
        for (int k = 0; k < 260; k++) {
            double a = k * Fx.TAU / 260;
            c.emit(new Spec(Kind.GLOW).pos(p).vel(Math.cos(a) * 2.6, r.nextGaussian() * 0.05, Math.sin(a) * 2.6)
                    .life(30).size(0.8).color(0xFF6A3A).drag(0.97).fade(1, 20));
        }
        Fx.shock(c, c.at(0, 0.4, 0), 2.4, 220, 0xFF4020, 34, 0.7);
    }
}
